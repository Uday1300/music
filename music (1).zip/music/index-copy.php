<?php
include_once 'config.php';

// fetch files
$sql = "select filename from tbl_files";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="index-copy.css">
    

</head>
<body>

    <div class="container"> 
    <div class="navbar" >
        <img src="img/logo.png" class="logo">
        <ul>
            <li><a href="#"><h3>HOME</h3></a></li>
            <li><a href="#"><h3>ABOUT US</h3></a></li>
            <li><a href="#"><h3>CONTACT</h3></a></li>
            <li><a href="login.php"><h3>LOGIN</h3></a></li>
        </ul>
    </div> 
    <br>
    <br>
    <hr>
    <br>
        <marquee direction="right"><h1>WELCOME TO THE WORLD OF MUSIC</h1></marquee>
        <br>
    <br>
    <br>
    <div class="content">
    <div class="row">
        <div class="col-xs-8 col-xs-offset-2 well">
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="left-col">
                <br>
<br>
<br>
<br>
<br>
            <legend><h2>Select File to Upload:</h2></legend><br><br>
            <div class="form-group">
                <input type="file" name="file1" />
            </div>
            <br><br><br>
            <div class="form-group">
                <input type="submit" name="submit" value="Upload" class="btn btn-info"/>
                </div>
            </div>
            <?php if(isset($_GET['st'])) { ?>
                <div class="alert alert-danger text-center">
                <?php if ($_GET['st'] == 'success') {
                        echo "File Uploaded Successfully!";
                    }
                    else
                    {
                        echo 'Invalid File Extension!';
                    } ?>
                </div>
            <?php } ?>
        </form>
        </div>
    </div>
    
    <br>
    <br>

    <div class="row">
        <div class="col-xs-8 col-xs-offset-2">
           
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        
                        <th>#</th>
                        <th>File Name</th>
                        <th>View</th>
                        <th>Download</th>
                    
                    </tr>
                </thead>

                <tbody>
                <?php
                $i = 1;
                
                while($row = mysqli_fetch_array($result)) { ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['filename']; ?></td>
                    <td><a href="uploads/<?php echo $row['filename']; ?>" target="_blank">View</a></td>
                    <td><a href="uploads/<?php echo $row['filename']; ?>" download>Download</td>
                </tr>
                <?php } ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
     </div>
</body>
</html>