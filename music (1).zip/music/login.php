<?php
include "config.php";
mysqli_select_db($con,"music");

if(isset($_POST['Submit'])){
	$query=mysqli_query($con,"select name,pass from register where name='$_POST[name]' AND pass='$_POST[pass]'");
	if( mysqli_num_rows($query)>0)
		header("Location:index-copy.php");
	else{
		// $sql="INSERT INTO register (name, contact,email,pass,cpass)VALUES('$_POST[name]','$_POST[contact]','$_POST[email]','$_POST[pass]','$_POST[cpass]')";
		// mysqli_query($con,$sql);
		// header("login.php");
		// exit();
		echo"invalid";
	}
}
mysqli_close($con)
?>



<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="login.css">
</head>

<body> 
  <br><br><br>

<h2>   
<p align="center">WELCOME!!</p></h2>
  <!-- <div class="row">
    <div class="cont-box">
      <h1>WELCOME!!</h1>
      <div class="bar"></div>
    </di -->
  <div class="row">
    <div class="cont-box">
      <h2>Login Form</h2>

<form action="login.php" method="post">
            <div class="cont-inputBox">
              <p>User Name</p>
      <input type="text" name="name" placeholder="username" required="" /><br/>
</div>
      <div class="cont-inputBox">
        <p>Password</p>
      <input type="password" name="pass" placeholder="password" required="" />
  </div>

    <button type="submit" name="Submit" class="myButton">Login
      </button><br><br>
    
      <h4>Don't have an account? We can fix that!<span>
        <a href="Reg.php" input type="submit"  class="myButton" >Sign Up</a>
    </span>
</h4>
    </div>
  </div>
</div>

  </form>
    </div>
</body>

</html>






















<!-- 
                <input type="text" name="name"  required="">
                <label>Username</label>
            </div>
            
            <div class="cont-inputBox">
                <input type="password" name="pass" required="">
                <label>Password</label>
            </div>
             -->
           <!-- 
            <input type="submit" name="Submit" class="myButton" value="Submit"><br><br>
            <div class="cont-inputBox">
                <label>New User...??</label><a href="Reg.php" style="top: 0;margin-left: 50%; position: absolute;padding: 10px 0;font-size: 20px;color: #c164c9;">Register Here</a>         
            </div><br><br><br><br>
            <div class="cont-inputBox">
                <label>Doesn't remember your password!!!</label><br><br><br>
            <a href="" style="top: 0;margin-left: 85%; position: absolute;padding: 10px 0;font-size: 20px;color: #c164c9;">Forgot Password </a>  
           </div> -->
      