<?php
include "config.php";
mysqli_select_db($con,"music");

if(isset($_POST['Submit'])){
	$query=mysqli_query($con,"select name from register where name='$_POST[name]'");
	if( mysqli_num_rows($query)>0)
		echo"already exist";
	else{
		$sql="INSERT INTO register (name, contact,email,pass,cpass)VALUES('$_POST[name]','$_POST[contact]','$_POST[email]','$_POST[pass]','$_POST[cpass]')";
		mysqli_query($con,$sql);
		echo" insert";
        //echo "inserted";
		header("Location:login.php");
		exit();
	}
}
mysqli_close($con)
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="register.css">
    
</head>

<body >
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  
    <div class="Reg-box">
        
        <h2>Register Here!!!</h2>
        <form  action="Reg.php" method="post">
            <div class="Reg-inputBox">
                <label>Enter Your Name :</label>
                
                <input type="text" name="name"  required="" placeholder="Enter your name"  />
               
            </div>
            
                <div class="Reg-inputBox">
                <label>Enter The Contact Number :</label>
                
                <input type="tel" name="contact"  required="" placeholder="Enter contact number" />
               
            </div>
            
            <div class="Reg-inputBox">
                <label>Enter The Email Id :</label>
               
                <input type="email"  name="email"  required="" placeholder="Enter email id" />
                </div>
               
            <div class="Reg-inputBox">
                <label>Enter The Password :</label>
               
                <input type="password"  name="pass"  required="" placeholder="Enter password" />
               
            </div>
            
            <div class="Reg-inputBox">
                <label>Confirm The Password :</label>
               
                <input type="password"  name="cpass" required="" placeholder="Confirm password" />
                
            </div>

            <br>
            <input type="Submit"  name="Submit" class="myButton" value="Submit"><br><br>


        </form>
    </div>
  
</body>

</html>